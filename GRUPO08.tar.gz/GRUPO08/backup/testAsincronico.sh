SLEEPTIME=5
a=0
while true
do
	sleep $SLEEPTIME
	a=$((a+1))
	echo $a
done

